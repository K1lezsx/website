<?php include("template/cabecera.php"); ?>

    <div class="jumbotron">
        <h1 class="display-3">Nosotros</h1>
        <p class="lead">Somos una empresa dedicada a la venta de ropa para gimnasio y equipo deportivo 
            <br> Siguenos en nuestras redes sociales para mas informacion y seguir comprando con nosotros
        </p>
        <hr class="my-2">
    </div>

<?php include("template/pie.php"); ?>