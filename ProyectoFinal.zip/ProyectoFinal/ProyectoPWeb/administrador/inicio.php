<?php include('template/cabecera.php')?>


            <div class="col-md-12">
                <div class="jumbotron">
                    <h1 class="display-3">Bienvenido al perfil de Administrador</h1>
                    <p class="lead">Porfavor haz un uso correcto de tus privilegios de administrador</p>
                    <hr class="my-2">
                    <p>More info</p>
                    <p class="lead">
                    <a class="btn btn-primary btn-lg" href="secciones/productos.php" role="button">Administrar Productos</a>
                    </p>
                </div>

            </div>
            
<?php include('template/pie.php')?>
        