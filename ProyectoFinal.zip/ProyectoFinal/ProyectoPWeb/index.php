<?php include("template/cabecera.php"); ?>
    
            <div class="jumbotron text-center">
                <h1 class="display-3">Bienvenido a Shopping Quiles</h1>
                <p class="lead">Esperamos que nuestros productos sean de tu agrado y te interese seguir comprando y ser parte de la comunidad </p>
                <hr class="my-2">
                <img src="img/SQuiles.jpeg">
                <br> 
                </p>
            </div>

<?php include("template/pie.php"); ?>